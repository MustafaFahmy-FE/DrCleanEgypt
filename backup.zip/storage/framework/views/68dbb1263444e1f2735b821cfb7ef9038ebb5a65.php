<div class="col-lg-4 col-md-4 col-sm-6">
    <div class="data_item cust">
        <img src="<?php echo e(get_image($item->image, 'items')); ?>" />
        <?php echo e($item->name); ?>

        <span> العدد : <?php echo e($quantity); ?> </span>
        <span> خصم : <?php echo e($discount == 0 ? 'لا يوجد' : $discount); ?> </span>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/orders/templates/order.blade.php ENDPATH**/ ?>