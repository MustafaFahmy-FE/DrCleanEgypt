<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget" style="padding: 25px">
                        <div class="row">
                            
                            <div class="col-lg-9 col-md-8">
                                 <table class="table table-bordered">
                                    <thead style="background-color:#dbefff">
                                        <tr>
                                            <th>رقم الطلب</th>
                                            <th>إسم العميل</th>
                                            <th> الأجمالى +</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                   <?php echo e(++$index); ?>

                                                </td>
                                                <td>
                                                   <?php echo e($order->client->name); ?>

                                                </td>
                                                <td>
                                                      <?php echo e($order->total_price_after_discount()); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <thead style="background-color: #dbefff">
                                        <tr>
                                            <th>رقم االمصروف</th>
                                            <th>إسم المصروف</th>
                                            <th> الأجمالى - </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e(++$index); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($expense->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($expense->price); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-lg-3 col-md-4">
                                <div class="daily_total">
                                    الإجمالى
                                    <span>
                                        <?php echo e($difference); ?> جنيه
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/reports/daily.blade.php ENDPATH**/ ?>