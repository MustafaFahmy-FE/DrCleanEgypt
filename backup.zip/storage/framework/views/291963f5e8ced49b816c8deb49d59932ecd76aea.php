<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget">
                        <div class="widget_title">الفاتورة</div>
                        <div class="widget_content">
                            <div class="bill">
                                <div class="info">
                                    <ul>
                                        <li class="w-100">
                                            رقم الفاتورة
                                            <span> # <?php echo e($order->id); ?> </span>
                                        </li>
                                        <li class="w-100">
                                            تاريخ الأستلام
                                            <span> <?php echo e($order->created_at->format('d-m-Y')); ?></span>
                                        </li>
                                        <li class="w-100">
                                            تاريخ التسليم
                                            <span> <?php echo e($order->working_days_count()->format('d-m-Y')); ?></span>
                                        </li>
                                    </ul>
                                    <img src="<?php echo e(asset('public/images/logo.png')); ?>" />
                                </div>
                                <div class="user">
                                    <div class="title">العميل</div>
                                    <ul>
                                        <li class="w-100">
                                            الأسم
                                            <span> <?php echo e($order->client->name); ?> </span>
                                        </li>
                                        <li class="w-100">
                                            تليفون
                                            <span> <?php echo e($order->client->phone); ?> </span>
                                        </li>

                                        <li class="w-100">
                                            منطقة
                                            <span> <?php echo e($order->client->address); ?> </span>
                                        </li>

                                        <li>
                                            بناية
                                            <span> <?php echo e($order->client->building); ?> </span>
                                        </li>
                                        <li>
                                            طابق
                                            <span> <?php echo e($order->client->floor); ?> </span>
                                        </li>
                                        <li>
                                            شقة
                                            <span> <?php echo e($order->client->apartment); ?> </span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="items">
                                    <ul>
                                        <li>
                                            الصنف
                                            <span> العدد </span>
                                        </li>
                                        <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php echo e($detail->item->name); ?>

                                                <span> <?php echo e($detail->quantity); ?> </span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <li>عدد الأصناف <span> <?php echo e($order->details()->count()); ?> </span></li>
                                    </ul>
                                </div>
                                <div class="info price">
                                    <ul>
                                        <li class="w-100">
                                            إجمالى المبيعات
                                            <span> <?php echo e($order->total); ?> </span>
                                        </li>
                                        <li class="w-100">
                                            خصم
                                            <span> <?php echo e($order->discount == 0 ? 'لا يوجد' : $order->discount . ' جنيه'); ?>

                                            </span>
                                        </li>
                                        <li class="w-100">
                                            الأجمالى
                                            <span> <?php echo e($order->total_after_discount()); ?> جنيه </span>
                                        </li>
                                    </ul>
                                    <div class="hint">
                                        <p>- لا تسلم الطلبات إلا مع إيصال الأستلام</p>
                                        <p>
                                            - الشركة غير مسؤلة عن الملابس المصبوغة والألوان غير
                                            الثابتة وعيوب الصناعة مالم يتم الأبلاغ عنها
                                        </p>
                                        <p>- الشركة غير مسؤلة عن البضاعه بعد شهر من إيداعها</p>
                                        <p>
                                            - فى حالى الفقد لا يتجاوز التعويض 5 أمثال قيمة الخدمة
                                        </p>
                                        <p>
                                            - الرقم الضريبي : xxxxxx
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-100 text-center mt-25">
                                <button class="link green_bc print_btn" onclick="window.print();">
                                    <span> طباعة الفاتورة </span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/orders/print.blade.php ENDPATH**/ ?>