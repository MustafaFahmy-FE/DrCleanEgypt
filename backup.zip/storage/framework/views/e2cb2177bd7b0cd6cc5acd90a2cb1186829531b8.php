<div class="modal-content">
    <div class="modal-body text-center">
        <button class="icon_link" data-dismiss="modal">
            <i class="fa fa-times"></i>
        </button>
        <div class="modal_title">
            <i class="far fa-user"></i> تعديل بيانات المستخدم
        </div>
        <form class="ajax-form" method="put" action="<?php echo e(route('users.update', ['id' => $user->id])); ?>">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label> إسم المستخدم </label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" />
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label> البريد الألكترونى </label>
                        <input type="email" class="form-control en" name="email" value="<?php echo e($user->email); ?>" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> كلمة المرور </label>
                        <input type="password" class="form-control" name="password" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> الوظيفة </label>
                        <select class="form-control" name="role">
                            <option <?php echo e($user->role == 'admin' ? 'selected' : ''); ?> value="admin">مدير</option>
                            <option <?php echo e($user->role == 'supervisor' ? 'selected' : ''); ?> value="supervisor">مشرف
                            </option>
                            <option <?php echo e($user->role == 'data-entry' ? 'selected' : ''); ?> value="data-entry">مدخل
                                بيانات
                            </option>
                        </select>
                    </div>
                </div>
            </div>
            <button class="link"><span> حفظ المعلومات </span></button>
        </form>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/users/edit.blade.php ENDPATH**/ ?>