<?php $__env->startPush('models'); ?>
    <div class="modal fade" id="add_item" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button class="icon_link" data-dismiss="modal">
                        <i class="fa fa-times"></i>
                    </button>
                    <div class="modal_title">
                        <i class="far fa-bookmark"></i> إضافة صنف جديد
                    </div>
                    <form method="post" action="<?php echo e(route('items.store')); ?>" class="ajax-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> صور الصنف </label>
                                    <input type="file" class="en" name="image" />
                                    <span class="hint"> مقاس الصورة 140 * 140 </span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> القسم </label>
                                    <select class="form-control" name="category_id">
                                        <option value="0">إختر القسم</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> إسم الصنف </label>
                                    <input type="text" class="form-control" name="name" />
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> سعر الغسيل </label>
                                    <input type="text" class="form-control" name="laundry_price" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> سعر الكي </label>
                                    <input type="text" class="form-control" name="ironing_price" />
                                </div>
                            </div>
                        </div>
                        <button class="link"><span> حفظ المعلومات </span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="common-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog " role="document" id="edit-area">

        </div>
    </div>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">
                            قائمة الأصناف

                            <button class="link green_bc widget_link" data-toggle="modal" data-target="#add_item">
                                + إضافة صنف
                            </button>
                        </div>
                        <div class="widget_content">
                            <div class="row">
                                <div class="col-12">
                                    <ul class="nav nav-tabs">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a data-toggle="tab" href="#t<?php echo e($index); ?>"
                                                    class="<?php echo e($index == 0 ? 'active' : ''); ?>">
                                                    <?php echo e($category->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="tab-content">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div id="t<?php echo e($index); ?>"
                                                class="tab-pane fade <?php echo e($index == 0 ? 'active show' : ''); ?> in">
                                                <div class="row">
                                                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                                                            <div class="item">
                                                                <img src="<?php echo e(get_image($item->image, 'items')); ?>" />
                                                                <h3><?php echo e($item->name); ?></h3>
                                                                <p>سعر الغسيل : <?php echo e($item->laundry_price); ?> جنيه</p>
                                                                <p>سعر الكي : <?php echo e($item->ironing_price); ?> جنيه</p>
                                                                <div class="btns">
                                                                    <button
                                                                        data-url="<?php echo e(route('items.delete', ['id' => $item->id])); ?>"
                                                                        class="delete-btn icon_link red_bc fa fa-times"></button>
                                                                    <button
                                                                        class="icon_link green_bc far fa-edit btn-modal-view"
                                                                        data-url="<?php echo e(route('items.edit', ['id' => $item->id])); ?>">
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <!--End Row-->
                        </div>
                        <!--End Widget Content-->
                    </div>
                    <!--End Widget-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/items/all.blade.php ENDPATH**/ ?>