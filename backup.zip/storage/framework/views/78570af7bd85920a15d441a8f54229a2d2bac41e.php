<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget order_head">
                        <h3>طلب رقم #<?php echo e($order->id); ?></h3>
                        <div class="btns">

                            <?php if($order->status == 0): ?>
                                <span class="status yellow_bc">
                                    <i class="fa fa-spinner fa-spin"></i>
                                    جارى التنفيذ
                                </span>
                            <?php elseif($order->status == 1): ?>
                                <span class="status green_bc">
                                    <i class="fa fa-check"></i>
                                    تم التفيذ
                                </span>
                            <?php else: ?>
                                <span class="status red_bc">
                                    <i class="fa fa-times"></i>
                                    خاطئ (Void)
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="widget">
                        <div class="widget_title">
                            <i class="far fa-user"></i> بيانات العميل
                        </div>
                        <div class="widget_content">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="data_item">
                                        <i class="fa fa-info"></i>
                                        إسم العميل
                                        <span> <?php echo e($order->client->name); ?> </span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="data_item">
                                        <i class="fa fa-phone"></i>
                                        رقم الهاتف
                                        <span class="en"> <?php echo e($order->client->phone); ?> </span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="data_item">
                                        <i class="fa fa-map-marker-alt"></i>
                                        العنوان
                                        <span>
                                            <?php echo e($order->client->address); ?>

                                        </span>
                                        <span> بلوك <?php echo e($order->client->building); ?> - الدور <?php echo e($order->client->floor); ?> -
                                            شقة
                                            <?php echo e($order->client->apartment); ?> </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="widget_title">
                            <i class="fa fa-info"></i> تفاصيل الطلب
                        </div>
                        <div class="widget_content">
                            <div class="row">
                                <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="data_item cust">
                                            <?php echo e($detail->item->name); ?>

                                            <span> العدد : <?php echo e($detail->quantity); ?> </span>
                                            <span> خصم :  <?php echo e($detail->discount == 0 || $detail->discount == null ? 'لا يوجد' : $detail->discount.' %'); ?>

                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!--End Row-->
                        </div>
                    </div>
                    <div class="widget">
                        <div class="widget_title">
                            <i class="fas fa-exclamation-triangle"></i>
                            ملاحظات
                        </div>
                        <div class="widget_content">
                            <?php $__currentLoopData = explode("\n", $order->notes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>- <?php echo e($note); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="widget ">
                        <div class="widget_title">تغيير حالة الطلب</div>
                        <form class="widget_content bill_total" method="get"
                            action="<?php echo e(route('orders.change_status', ['id' => $order->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <li>
                                <select name="status" class="form-control">
                                    <option value="0" <?php echo e($order->status == 0 ? 'selected' : ''); ?>>قيد التنفيذ
                                    </option>
                                    <option value="1" <?php echo e($order->status == 1 ? 'selected' : ''); ?>>تم التنفيذ
                                    </option>
                                    <option value="-1" <?php echo e($order->status == -1 ? 'selected' : ''); ?>>خاطئ
                                    </option>
                                </select>
                            </li>
                            <div class="col-12">
                                <button class="link green_bc">
                                    <span>
                                        <i class="fa fa-info"></i>
                                        تغيير الحاله
                                    </span>
                                </button>
                            </div>
                        </form>

                    </div>
                    <div class="widget ">
                        <div class="widget_title">تغيير حالة الدفع</div>
                        <form class="widget_content bill_total" method="get"
                            action="<?php echo e(route('orders.change_payment', ['id' => $order->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <li>
                                <select name="payment" class="form-control">
                                    <option value="0" <?php echo e($order->payment == 0 ? 'selected' : ''); ?>>لم يتم السداد
                                    </option>
                                    <option value="1" <?php echo e($order->payment == 1 ? 'selected' : ''); ?>>تم السداد
                                    </option>
                                </select>
                            </li>
                            <div class="col-12">
                                <button class="link green_bc">
                                    <span>
                                        <i class="fa fa-info"></i>
                                        تغيير الحاله
                                    </span>
                                </button>
                            </div>
                        </form>

                    </div>
                    <div class="widget ">
                        <div class="widget_title en_font">Asset</div>
                        <div class="bill" id="bill-asset">
                            <div class="info">
                                <ul>
                                    <li class="w-100">
                                        رقم الفاتورة
                                        <span> # <?php echo e($order->id); ?> </span>
                                    </li>
                                    <li class="w-100">
                                        تاريخ الأستلام
                                        <span> <?php echo e($order->created_at->format('d-m-Y')); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="user">
                                <div class="title">العميل</div>
                                <ul>
                                    <li class="w-100">
                                        الأسم
                                        <span> <?php echo e($order->client->name); ?> </span>
                                    </li>
                                    <li class="w-100">
                                        تليفون
                                        <span> <?php echo e($order->client->phone); ?> </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="w-100 text-center mt-25">

                            <a class="link green_bc" href="<?php echo e(route('orders.asset', ['id' => $order->id])); ?>">
                                <span>
                                    <i class="fa fa-print"></i>
                                    طباعة
                                    <div class="en_font"> Asset</div>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="widget ">
                        <div class="widget_title">السعر الأجمالى</div>
                        <div class="widget_content bill_total">
                            <li>
                                قيمة الطلب
                                <span> <?php echo e($order->total_before_item_discount()); ?> جنيه </span>
                            </li>
                            <li>
                                خصم
                                <span> 
                                    <?php echo e($order->total_discount()); ?>

                                جنيه </span>
                            </li>
                            <li>إجمالى الفاتورة 
                                <span> <?php echo e($order->total_price_after_discount()); ?> جنيه</span>
                            </li>
                        </div>
                        <div class="col-12">
                            <a class="link green_bc" href="<?php echo e(route('orders.print', ['id' => $order->id])); ?>">
                                <span>
                                    <i class="fa fa-print"></i>
                                    طباعة الفاتورة
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/orders/show.blade.php ENDPATH**/ ?>