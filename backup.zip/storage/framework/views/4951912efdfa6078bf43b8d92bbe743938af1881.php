<option value="غسيل">غسيل <?php echo e($item->laundry_price); ?></option>
<option value="كي">كي <?php echo e($item->ironing_price); ?></option>
<?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/orders/templates/status.blade.php ENDPATH**/ ?>