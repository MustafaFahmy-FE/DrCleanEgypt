<div class="col-lg-4 col-md-4 col-sm-6" id="order-item">
    <div class="data_item cust">
        <?php echo e($item->name); ?>

        <span> العدد : <?php echo e($quantity); ?> </span>
        <span> خصم : <?php echo e($discount == 0 ? 'لا يوجد' : $discount); ?> % </span>
        <a class="fas fa-times icon_link delete-button" title="حذف الصنف" ></a>
    </div>
    
</div>
<?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/orders/templates/order.blade.php ENDPATH**/ ?>