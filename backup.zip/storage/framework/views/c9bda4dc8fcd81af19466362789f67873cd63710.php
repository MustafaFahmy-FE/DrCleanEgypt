<!DOCTYPE html>
<html lang="ar" dir="rtl"
    style="width: 110mm; max-width:110mm; padding: 0;margin: 0;    box-sizing: border-box;">

<head>
    <!-- Meta Tags
        ==============================-->
    <meta charset="utf-8" />
    <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>" />
    <style>
        .bill .title {
            border: 1px solid #000;
            font-size: 14px;
            padding: 7px 5px;
            margin: 15px 0;
        }

        .bill .hint {
            border: 1px solid #000;
            color: #000;
        }

        .bill ul li span {
            border: 1px solid #000;
            margin-left: 5px;

        }

        .bill .price ul li span {
            color: #000;
            min-width: 48%;
            border: 1px solid #000;
        }

        .bill .hint p {
            font-size: 10px;
            line-height: 25px;
            margin: 0;
            color: #000;
        }

    </style>
</head>

<body
    style="width: 110mm; max-width:110mm;     overflow: visible;padding: 0;margin: 0;    box-sizing: border-box;">

    <div class="bill"
        style="width: 110mm;max-width:110mm; text-align: start;background-color: #fff;padding: 10px;margin: 0; border: 0;    box-sizing: border-box; color: #000;">
        <div class="info">
            <ul>
                <li class="w-100">
                    رقم الفاتورة
                    <span> # <?php echo e($order->id); ?> </span>
                </li>
                <li class="w-100">
                    تاريخ الأستلام
                    <span> <?php echo e($order->created_at->format('d-m-Y')); ?></span>
                </li>
                <li class="w-100">
                    تاريخ التسليم
                    <span> <?php echo e($order->working_days_count()->format('d-m-Y')); ?></span>
                </li>
                <li class="w-100">
                    إسم الموظف
                    <span> <?php echo e($order->employee_name); ?></span>
                </li>
            </ul>
            <img style="filter: none;" src="<?php echo e(asset('public/images/logo_gray.png')); ?>" />
        </div>
        <div class="user">
            <div class="title">العميل</div>
            <ul>
                <li class="w-100">
                    الأسم
                    <span> <?php echo e($order->client->name); ?> </span>
                </li>
                <li class="w-100">
                    تليفون
                    <span> <?php echo e($order->client->phone); ?> </span>
                </li>

                <li class="w-100">
                    منطقة
                    <span> <?php echo e($order->client->address); ?> </span>
                </li>

                <li>
                    بناية
                    <span> <?php echo e($order->client->building); ?> </span>
                </li>
                <li>
                    طابق
                    <span> <?php echo e($order->client->floor); ?> </span>
                </li>
                <li>
                    شقة
                    <span> <?php echo e($order->client->apartment); ?> </span>
                </li>
               
            </ul>
        </div>
        <div class="items">
            <ul>
                <li style="
    border: 1px solid #000;
    font-size: 14px;
    padding: 5px;
    min-width: 96%;
    width: 96%;
">
                    
                    <span> الصنف (القسم)</span>
                    
                    <span> الخدمة </span>
                    
                    <span>السعر </span>
                    <span> الكمية </span>
                    <span> الإجمالى </span>
                </li>
                <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        
                       <span style="font-size: 16px;"> 
                            <?php echo e($detail->item->name); ?>

                            <?php if($detail->item->category->id == 1): ?>
                                (ر)
                            <?php elseif($detail->item->category->id == 2): ?>
                                (ح)
                            <?php elseif($detail->item->category->id == 3): ?>
                                (أ)
                            <?php elseif($detail->item->category->id == 5): ?>
                                (م)
                            <?php else: ?>
                                (س)
                            <?php endif; ?>
                       </span> <!-- الصنف  -->
                       <span> <?php echo e($detail->status); ?> </span> <!-- الخدمة  -->
                       <span> <?php echo e($detail->price/$detail->quantity); ?>   </span> <!-- السعر -->
                       <span> <?php echo e($detail->quantity); ?> </span> <!-- الكمية  -->
                       <span> <?php echo e($detail->price); ?>  </span> <!-- الاجمالى -->
                       
                        <!--<span> <?php echo e($detail->item->category->name); ?> </span>-->
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li style="
    border: 1px solid #000;
    font-size: 14px;
    padding: 5px;
    min-width: 96%;
    width: 96%;
"> عدد الأصناف <span> <?php echo e($order->details()->count()); ?> </span></li>
            </ul>
        </div>
        <div class="info price">
            <ul>
                  <li class="w-100">
                    توصيل للمنزل
                    <span> <?php echo e($order->delivery); ?> </span>
                </li>
                <li class="w-100">
                    خدمات إضافية
                    <span> <?php echo e($order->service); ?> </span>
                </li>
                <li class="w-100">
                    إجمالى المبيعات
                    <span> <?php echo e($order->total_before_item_discount()); ?> جنيه </span>
                </li>
                <li class="w-100">
                    خصم 
                    <span> <?php echo e($order->total_discount()); ?> جنيه </span>
                </li>
                <li class="w-100">
                    الأجمالى
                    <span> <?php echo e($order->total_price_after_discount()); ?> جنيه</span>
                </li>
            </ul>
            <div class="hint">
                <p>- لا تسلم الطلبات إلا مع إيصال الأستلام</p>
                <p>
                    - الشركة غير مسؤلة عن الملابس المصبوغة والألوان غير
                    الثابتة وعيوب الصناعة مالم يتم الأبلاغ عنها
                </p>
                <p>- الشركة غير مسؤلة عن البضاعه بعد شهر من إيداعها</p>
                <p>
                    - فى حالى الفقد لا يتجاوز التعويض 5 أمثال قيمة الخدمة
                </p>
                <p>
                    - الرقم الضريبي : 663-221-476 </p>
            </div>
        </div>
        <div class="w-100 text-center mt-25">
            <button class="link green_bc print_btn" onclick="window.print();"  style="font-family: sans-serif; font-size: 14px;">
                <span> طباعة الفاتورة </span>
            </button>
            <a href="<?php echo e(route('orders.show' , ['id' => $order->id])); ?>" class="link blue_bc return_btn" >
                <span> العودة للخلف</span>
            </a>
        </div>
    </div>


    <!-- JS & Vendor Files
    ==========================================-->
    <script src="<?php echo e(asset('public/vendor/jquery/jquery.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('public/vendor/bootstrap/bootstrap.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/drcleanegypt/public_html/resources/views/pages/orders/print.blade.php ENDPATH**/ ?>