<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">تقارير المبيعات</div>
                        <div class="widget_content">
                            <form class="report_form" method="get" action="<?php echo e(route('search')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> من </label>

                                                <div class="inline_data">
                                                    <i class="fa fa-calendar-alt"></i>

                                                    <input type="text" class="form-control flatpickr-input" name="from" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> إلى </label>

                                                <div class="inline_data">
                                                    <i class="fa fa-calendar-alt"></i>

                                                    <input type="text" class="form-control flatpickr-input" name="to" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button class="link green_bc" type="submit">
                                        <span> مشاهدة التقرير </span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/reports/index.blade.php ENDPATH**/ ?>