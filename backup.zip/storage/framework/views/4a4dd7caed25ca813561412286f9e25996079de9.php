<div class="modal-content">
    <div class="modal-body text-center">
        <button class="icon_link" data-dismiss="modal">
            <i class="fa fa-times"></i>
        </button>
        <div class="modal_title">
            <i class="far fa-user"></i> تعديل بيانات العميل
        </div>
        <form method="put" action="<?php echo e(route('clients.update', ['id' => $client->id])); ?>" class="ajax-form">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label> إسم العميل </label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($client->name); ?>" />
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label> العنوان </label>
                        <input type="text" class="form-control" name="address" value="<?php echo e($client->address); ?>" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> رقم التليفون </label>
                        <input type="text" class="form-control" name="phone" value="<?php echo e($client->phone); ?>" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> رقم المبنى </label>
                        <input type="text" class="form-control" value="<?php echo e($client->building); ?>" name="building" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> الدور </label>
                        <input type="text" class="form-control" value="<?php echo e($client->floor); ?>" name="floor" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label> رقم الشقة </label>
                        <input type="text" class="form-control" value="<?php echo e($client->apartment); ?>" name="apartment" />
                    </div>
                </div>
            </div>
            <button class="link" type="submit"><span> حفظ المعلومات </span></button>
        </form>
    </div>
</div>
<?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/clients/edit.blade.php ENDPATH**/ ?>