<?php $__env->startPush('models'); ?>
    <div class="modal fade" id="add_client" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button class="icon_link" data-dismiss="modal">
                        <i class="fa fa-times"></i>
                    </button>
                    <div class="modal_title">
                        <i class="far fa-client"></i> إضافة عميل جديد
                    </div>
                    <form method="post" action="<?php echo e(route('clients.store')); ?>" class="ajax-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label> إسم العميل </label>
                                    <input type="text" class="form-control" name="name" />
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label> العنوان </label>
                                    <input type="text" class="form-control" name="address" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> رقم التليفون </label>
                                    <input type="text" class="form-control" name="phone" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> رقم المبنى </label>
                                    <input type="text" class="form-control" name="building" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> الدور </label>
                                    <input type="text" class="form-control" name="floor" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> رقم الشقة </label>
                                    <input type="text" class="form-control" name="apartment" />
                                </div>
                            </div>
                        </div>
                        <button class="link" type="submit"><span> حفظ المعلومات </span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="common-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog " role="document" id="edit-area">

        </div>
    </div>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">
                            قائمة العملاء

                            <button class="link green_bc widget_link" data-toggle="modal" data-target="#add_client">
                                + إضافة عميل
                            </button>
                        </div>
                        <div class="widget_content">
                            <div class="table-responsive">
                                <table class="table table-bordered datatable_full" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>رقم العميل</th>
                                            <th>إسم العميل</th>
                                            <th>رقم الهاتف</th>
                                            <th>العنوان</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td># <?php echo e(++$index); ?></td>
                                                <td><?php echo e($client->name); ?></td>
                                                <td><?php echo e($client->phone); ?></td>
                                                <td><?php echo e($client->address); ?></td>
                                                <td>
                                                    <button class="fa fa-edit icon_link green_bc btn-modal-view"
                                                        data-url="<?php echo e(route('clients.edit', ['id' => $client->id])); ?>">
                                                    </button>
                                                    <button class="fa fa-times icon_link red_bc delete-btn"
                                                        data-url="<?php echo e(route('clients.delete', ['id' => $client->id])); ?>"></button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/clients/all.blade.php ENDPATH**/ ?>