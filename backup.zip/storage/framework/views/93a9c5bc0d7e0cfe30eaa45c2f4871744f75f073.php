<option value="غسيل">غسيل <?php echo e($item->laundry_price); ?></option>
<option value="كي">كي <?php echo e($item->ironing_price); ?></option>
<?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/orders/templates/status.blade.php ENDPATH**/ ?>