<aside>
    <button class="toggle-btn custom-btn">
        <i class="fa fa-times"></i>
    </button>
    <h3 class="logo">
        <img src="<?php echo e(asset('public/images/logo.png')); ?>" />

        <?php echo e(auth()->user()->name); ?>

    </h3>
    <ul>
        <li class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> الرئيسية </a>
        </li>
        <li class="<?php echo e(request()->routeIs('categories.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-info"></i> الأقسام <span>
                    <?php echo e($category_counter); ?> </span>
            </a>
        </li>
        <li class="<?php echo e(request()->routeIs('items.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('items.index')); ?>"><i class="far fa-bookmark"></i> الأصناف <span> <?php echo e($item_counter); ?>

                </span>
            </a>
        </li>
        <li
            class="<?php echo e(request()->routeIs('orders.index') || request()->routeIs('orders.edit') || request()->routeIs('orders.print') || request()->routeIs('orders.show') || request()->routeIs('orders.create') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-list"></i> الطلبات <span>
                    <?php echo e($order_counter); ?>

                </span>
            </a>
        </li>
        <li class="<?php echo e(request()->routeIs('clients.index') || request()->routeIs('clients.show') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('clients.index')); ?>"><i class="fa fa-users"></i> العملاء <span>
                    <?php echo e($client_counter); ?>

                </span>
            </a>
        </li>
        <?php if(auth()->user()->role == 'admin'): ?>
            <li class="<?php echo e(request()->routeIs('users.index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-cog"></i> المستخدمين <span>
                        <?php echo e($user_counter); ?>

                    </span>
                </a>
            </li>
            <li class="<?php echo e(request()->routeIs('employees.index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('employees.index')); ?>"><i class="fa fa-users"></i> الموظفين <span>
                        <?php echo e($employee_counter); ?>

                    </span>
                </a>
            </li>
        <?php endif; ?>
        <li class="<?php echo e(request()->routeIs('reports') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('reports')); ?>"><i class="far fa-file"></i> تقارير المبيعات </a>
        </li>
        <li class="<?php echo e(request()->routeIs('reports.report') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('reports.report')); ?>"><i class="far fa-file"></i> تقارير الكي والغسيل </a>
        </li>
        <li class="<?php echo e(request()->routeIs('expenses.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('expenses.index')); ?>"><i class="fas fa-dollar-sign"></i> المصروفات </a>
        </li>
        <li class="<?php echo e(request()->routeIs('attendance.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-clipboard"></i> الحضور والانصراف</a>
        </li>
    </ul>
</aside>
<?php /**PATH /home/drcleanegypt/public_html/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>