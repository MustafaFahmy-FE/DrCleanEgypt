<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">
                            قائمة الطلبات

                            <a href="<?php echo e(route('orders.create')); ?>" class="link green_bc widget_link">
                                <span> + إضافة طلب جديد </span>
                            </a>
                        </div>
                        <div class="widget_content">
                            <div class="table-responsive">
                                <table class="table table-bordered datatable_full" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>رقم الطلب</th>
                                            <th>إسم العميل</th>
                                            <th>تاريخ الأستلام</th>
                                            <th> تاريخ التسليم</th>
                                            <th>الأجمالى</th>
                                            <th>الحالة</th>
                                            <th>حاله السداد</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('orders.show', ['id' => $order->id])); ?>"
                                                        class="table_link"> <?php echo e($order->id); ?>

                                                    </a>
                                                </td>

                                                <td><?php echo e($order->client->name); ?></td>
                                                <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                                <td><?php echo e($order->working_days_count()->format('d-m-Y')); ?></td>
                                                <td><?php echo e($order->total_price_after_discount()); ?></td>
                                                <td>
                                                    <?php if($order->status == 0): ?>
                                                        <span class="status yellow_bc"> جارى التنفيذ </span>
                                                    <?php elseif($order->status == 1): ?>
                                                        <span class="status green_bc"> تم التنفيذ </span>
                                                    <?php else: ?>
                                                        <span class="status red_bc"> خاطئ  (Void)</span>
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php if($order->payment == 0): ?>
                                                        <span class="status yellow_bc"> لم يتم السداد </span>
                                                    <?php else: ?>
                                                        <span class="status green_bc"> تم السداد </span>
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <a class="fa fa-info icon_link" title="تفاصيل الطلب"
                                                        href="<?php echo e(route('orders.show', ['id' => $order->id])); ?>"></a>
                                                    <?php if($order->status == 1): ?>
                                                        <a href="<?php echo e(route('orders.print', ['id' => $order->id])); ?>"
                                                            class="link green_bc">
                                                            <span> طباعة الفاتورة </span>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/orders/all.blade.php ENDPATH**/ ?>