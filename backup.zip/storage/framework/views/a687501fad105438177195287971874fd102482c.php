<?php $__env->startPush('models'); ?>
    <div class="modal fade" id="add_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button class="icon_link" data-dismiss="modal">
                        <i class="fa fa-times"></i>
                    </button>
                    <div class="modal_title">
                        <i class="far fa-user"></i> إضافة مستخدم جديد
                    </div>
                    <form method="post" class="ajax-form" action="<?php echo e(route('users.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> إسم المستخدم </label>
                                    <input type="text" class="form-control" name="name" />
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> البريد الألكترونى </label>
                                    <input type="email" class="form-control en" name="email" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> كلمة المرور </label>
                                    <input type="password" class="form-control" name="password" />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> الوظيفة </label>
                                    <select class="form-control" name="role">
                                        <option value="admin">مدير</option>
                                        <option value="cachier">كاشير</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <button class="link" type="submit"><span> حفظ المعلومات </span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="common-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog " role="document" id="edit-area">

        </div>
    </div>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">
                            قائمة المستخدمين

                            <button class="link green_bc widget_link" data-toggle="modal" data-target="#add_user">
                                + إضافة مستخدم
                            </button>
                        </div>
                        <div class="widget_content">
                            <div class="table-responsive">
                                <table class="table table-bordered datatable_full" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>رقم الموظف</th>
                                            <th>إسم الموظف</th>
                                            <th>البريد الألكترونى</th>
                                            <th>الوظيفة</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$index); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><span class="en"><?php echo e($user->email); ?></span></td>
                                                <td>
                                                    <?php switch($user->role):
                                                        case ('admin'): ?>
                                                            مدير
                                                        <?php break; ?>
                                                        <?php case ('cachier'): ?>
                                                            كاشير
                                                        <?php break; ?>

                                                        <?php default: ?>

                                                    <?php endswitch; ?>
                                                </td>
                                                <td>
                                                    <?php if(auth()->user()->role == 'admin'): ?>
                                                        <button class="fa fa-edit icon_link green_bc btn-modal-view"
                                                            data-url="<?php echo e(route('users.edit', ['id' => $user->id])); ?>">
                                                        </button>
                                                        <button class="fa fa-times icon_link red_bc delete-btn"
                                                            data-url="<?php echo e(route('users.delete', ['id' => $user->id])); ?>"></button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/users/all.blade.php ENDPATH**/ ?>