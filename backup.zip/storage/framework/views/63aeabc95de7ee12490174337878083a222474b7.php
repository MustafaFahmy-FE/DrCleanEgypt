<?php $__env->startPush('models'); ?>
    <div class="modal fade" id="add_expense" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button class="icon_link" data-dismiss="modal">
                        <i class="fa fa-times"></i>
                    </button>
                    <div class="modal_title">
                        <i class="fa fa-info"></i> إضافة مصروف  جديد
                    </div>
                    <form method="post" class="ajax-form" action="<?php echo e(route('expenses.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label> إسم المصروف </label>
                                    <input type="text" class="form-control" name="name" />
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label> قيمه المصروف </label>
                                    <input type="number" class="form-control" name="price" />
                                </div>
                            </div>
                        </div>
                        <button class="link" type="submit"><span> حفظ المعلومات </span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="common-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog " role="document" id="edit-area">

        </div>
    </div>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="widget">
                        <div class="widget_title">
                            المصروفات

                            <button class="link green_bc widget_link" data-toggle="modal" data-target="#add_expense">
                                + إضافة مصروف
                            </button>
                        </div>
                        <div class="widget_content">
                            <div class="table-responsive">
                                <table class="table table-bordered datatable_full" style="width: 100%">
                                    <thead>
                                        <tr>
                                            <th>رقم المصروف</th>
                                            <th>إسم المصروف</th>
                                            <th>قيمه المصروف</th>
                                            <th>أنشئت في</th>
                                            <?php if(auth()->user()->role == 'admin'): ?>
                                                <th></th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e(++$index); ?></td>
                                                <td><?php echo e($expense->name); ?></td>
                                                <td><?php echo e($expense->price); ?></td>
                                                <td><?php echo e($expense->created_at->format('d-m-Y H:i')); ?></td>
                                                <?php if(auth()->user()->role == 'admin'): ?>
                                                    <td>
                                                        <button class="fa fa-edit icon_link green_bc btn-modal-view"
                                                            data-url="<?php echo e(route('expenses.edit', ['id' => $expense->id])); ?>">
                                                        </button>
                                                        <button class="fa fa-times icon_link red_bc delete-btn"
                                                            data-url="<?php echo e(route('expenses.delete', ['id' => $expense->id])); ?>"></button>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/dev/resources/views/pages/expenses/all.blade.php ENDPATH**/ ?>