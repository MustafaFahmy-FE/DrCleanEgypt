<div class="col-sm-6">
    <div class="data_item">
        <i class="fa fa-info"></i>
        إسم العميل
        <span> <?php echo e($client->name); ?> </span>
    </div>
</div>
<div class="col-sm-6">
    <div class="data_item">
        <i class="fa fa-phone"></i>
        رقم الهاتف
        <span class="en"> <?php echo e($client->phone); ?> </span>
    </div>
</div>
<div class="col-sm-12">
    <div class="data_item">
        <i class="fa fa-map-marker-alt"></i>
        العنوان
        <span>
            <?php echo e($client->address); ?>

        </span>
        <span> بلوك <?php echo e($client->building); ?> - الدور <?php echo e($client->floor); ?> - شقة <?php echo e($client->apartment); ?> </span>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/drclean/resources/views/pages/orders/templates/client.blade.php ENDPATH**/ ?>