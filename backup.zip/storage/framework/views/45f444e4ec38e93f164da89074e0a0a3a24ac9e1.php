
<?php $__env->startSection('content'); ?>
    <div class="dashboard_content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="widget">
                        <div class="widget_title">
                            <i class="far fa-user"></i> بيانات العميل
                        </div>
                        <div class="widget_content">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="data_item">
                                        <i class="fa fa-info"></i>
                                        إسم العميل
                                        <span> <?php echo e($client->name); ?> </span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="data_item">
                                        <i class="fa fa-phone"></i>
                                        رقم الهاتف
                                        <span class="en"> <?php echo e($client->phone); ?> </span>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="data_item">
                                        <i class="fa fa-map-marker-alt"></i>
                                        العنوان
                                        <span>
                                            <?php echo e($client->address); ?>

                                        </span>
                                        <span> بلوك <?php echo e($client->building); ?> - الدور <?php echo e($client->floor); ?> -
                                            شقة
                                            <?php echo e($client->apartment); ?> </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="widget ">
                        <div class="widget_title">إحصائيات</div>
                        <div class="widget_content bill_total">
                            <li>
                                عدد الطلبات
                                <span>
                                    <?php echo e($client->orders->count()); ?></span>
                            </li>
                            <li>
                                إجمالي الطلبات
                                <span>
                                    <?php echo e($client->orders->sum('total')); ?></span>
                            </li>
                            <li>
                                إجمالي المسدد
                                <span>
                                    <?php echo e($client->orders->where('payment', 1)->sum('total')); ?></span>
                            </li>
                            <li>
                                غير المسدد
                                <span>
                                    <?php echo e($client->orders->where('payment', 0)->sum('total')); ?></span>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="widget">
                    <div class="widget_title">
                        <i class="fa fa-info"></i> الطلبات
                    </div>
                    <div class="widget_content">
                        <div class="table-responsive">
                            <table class="table table-bordered datatable_full" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th>رقم الطلب</th>
                                        <th>تاريخ الأستلام</th>
                                        <th> تاريخ التسليم</th>
                                        <th>الأجمالى</th>
                                        <th>الحالة</th>
                                        <th>حاله السداد</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $client->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('orders.show', ['id' => $order->id])); ?>"
                                                    class="table_link">
                                                    <?php echo e($order->id); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                            <td><?php echo e($order->working_days_count()->format('d-m-Y')); ?></td>
                                            <td><?php echo e($order->total_price_after_discount()); ?></td>
                                            <td>
                                                <?php if($order->status == 0): ?>
                                                    <span class="status yellow_bc"> جارى التنفيذ </span>
                                                <?php elseif($order->status == 1): ?>
                                                    <span class="status green_bc"> تم التنفيذ </span>
                                                <?php else: ?>
                                                    <span class="status red_bc"> خاطئ (Void)</span>
                                                <?php endif; ?>

                                            </td>
                                            <td>
                                                <?php if($order->payment == 0): ?>
                                                    <span class="status yellow_bc"> لم يتم السداد </span>
                                                <?php else: ?>
                                                    <span class="status green_bc"> تم السداد </span>
                                                <?php endif; ?>

                                            </td>
                                            <td>
                                                <a class="fa fa-info icon_link" title="تفاصيل الطلب"
                                                    href="<?php echo e(route('orders.show', ['id' => $order->id])); ?>"></a>
                                                <?php if($order->status == 1): ?>
                                                    <a href="<?php echo e(route('orders.print', ['id' => $order->id])); ?>"
                                                        class="link green_bc">
                                                        <span> طباعة الفاتورة </span>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if(auth()->user()->role == 'admin'): ?>
                                                    <button data-url="<?php echo e(route('orders.delete', ['id' => $order->id])); ?>"
                                                        class="delete-btn icon_link red_bc fa fa-trash"></button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!--End Row-->
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drcleanegypt/public_html/resources/views/pages/clients/show.blade.php ENDPATH**/ ?>