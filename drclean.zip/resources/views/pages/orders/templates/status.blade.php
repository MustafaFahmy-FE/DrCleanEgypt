<option value="غسيل">غسيل {{ $item->laundry_price }}</option>
<option value="كي">كي {{ $item->ironing_price }}</option>
